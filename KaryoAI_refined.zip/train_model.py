"""Training hand-off scaffold.
Install requirements-model.txt and replace this validator with a task-specific PyTorch trainer
after acquiring licensed expert-labelled masks and chromosome classes.
"""
import json
from pathlib import Path
import argparse
p=argparse.ArgumentParser(); p.add_argument('--config',default='train_config.json'); a=p.parse_args()
config=json.loads(Path(a.config).read_text(encoding='utf-8'))
assert config['species'] in {'human','mouse'}
print('Configuration valid. Training requires labelled data and the optional model dependencies.')
