---
title: KaryoAI
emoji: 🧬
colorFrom: blue
colorTo: purple
sdk: streamlit
app_file: streamlit_app.py
pinned: false
---

# KaryoAI research prototype

KaryoAI is a local, research-only workflow assistant for reviewing chromosome images. It produces a **draft** karyogram, structured JSON, and a Markdown report. It is not a diagnostic device and no output may be used for patient care without independent review and formal laboratory validation.

> The block above is Hugging Face Space metadata — it tells the Space to launch `streamlit_app.py` with the Streamlit SDK. It's inert if you just run this locally.

## Quick start

Install the lightweight baseline dependencies:

**macOS / Linux**
```bash
python3 -m pip install -r requirements-app.txt
python3 karyo_ai_cli.py path/to/image.png --out-dir runs/case_001 --species human
```

**Windows**
```powershell
py -m pip install -r requirements-app.txt
py .\karyo_ai_cli.py "C:\path\to\image.png" --out-dir .\runs\case_001 --species human
```

The baseline uses classical thresholding and connected components. It can find chromosome-like objects and create a low-confidence draft layout, but it **cannot reliably identify chromosomes 1–22/X/Y** without trained models or expert annotations.

For expert-provided assignments, make a CSV with `object_id,chromosome_label,status,migrated,dislocated,notes` and pass it with `--annotations`.

```bash
python3 karyo_ai_cli.py sample.png --out-dir runs/sample --annotations annotations.csv
```

## Optional review interface

```bash
python3 -m pip install streamlit
streamlit run streamlit_app.py
```

The UI displays the mandatory research disclaimer and requires a named human reviewer before an export can be marked reviewed.

## Deploying on Hugging Face Spaces (for peer testing)

1. Create a new Space, SDK = **Streamlit**.
2. Push this folder's contents to the Space's repo — the YAML block at the top of this README is what Spaces reads to configure the app. Spaces installs from the root `requirements.txt` (already included here, mirroring `requirements-app.txt`).
3. Do **not** commit `requirements-model.txt` as the Space's requirements file — it pulls in torch/torchvision/opencv/scikit-image, which are unused by the baseline app and will slow the build considerably. It's kept in the repo purely as a reference for the future training hand-off.
4. Only upload de-identified / synthetic images for any demo data you commit — see the note in `AI_KARYOTYPE_PIPELINE_GUIDE.md`. Spaces are public by default unless set to private.

## Model and dataset scaffolding

`dataset_connector_cli.py` creates a manifest from a local classification/COCO-style dataset folder. `train_model.py` validates the training configuration and documents the hand-off point for a PyTorch segmentation/classification trainer. Public-source URLs are references only: download and licensing remain the operator's responsibility.

See [AI_KARYOTYPE_PIPELINE_GUIDE.md](AI_KARYOTYPE_PIPELINE_GUIDE.md) for the pipeline, data conventions, and limitations.
